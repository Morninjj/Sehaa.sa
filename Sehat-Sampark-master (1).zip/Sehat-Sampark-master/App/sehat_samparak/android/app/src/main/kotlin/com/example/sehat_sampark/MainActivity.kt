package com.example.sehat_sampark

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
