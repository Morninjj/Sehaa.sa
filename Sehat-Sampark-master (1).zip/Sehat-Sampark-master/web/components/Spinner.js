import React from "react";

const SpinnerLoader = () => {
  return <div className="loader"></div>;
};

export default SpinnerLoader;
